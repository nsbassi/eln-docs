package insight.npcil.eventpx.techauthcheck

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class TechauthcheckApplication {

	static void main(String[] args) {
		SpringApplication.run TechauthcheckApplication, args
	}
}
