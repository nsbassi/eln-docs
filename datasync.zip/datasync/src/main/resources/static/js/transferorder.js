/**
 * Created by Akbar on 10/27/2017.
 */
var transferOrder = {};
transferOrder.List = {
    init: function () {

    },
}