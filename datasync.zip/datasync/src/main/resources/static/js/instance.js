var plmInstance = {};
plmInstance.List = {
    init: function () {
        $('#btnMarkLocal').click(function () {
            plmInstance.List.markLocal();
        });

        $('#btnDelete').click(function () {
            plmInstance.List.delete();
        });
    },

    confirmDelete: function (id, name) {
        $('#instanceId').val(id);
        $('#deleteMsg').html('Are you sure you want to delete ' +
            '<em>' + name + '</em> instance?');
        $('#deleteDialog').modal("show");
    },

    delete: function () {
        var id = $('#instanceId').val();
        var callback = function (response) {
            var result = $.parseJSON(response);
            $('#deleteDialog').modal("hide");
            if (result.status) {
                showNotification(result.message, NotificationType.success);
                $('#__' + id).remove();
            } else {
                showNotification(result.message, NotificationType.error);
            }
        };
        var callObj = {
            url: 'delete/' + parseInt(id),
            method: HTTP_METHODS.GET,
            callback: callback
        }
        doAjax(callObj);
    },

    confirmMarkLocal: function (id, name) {
        $('#instanceId').val(id);
        $('#markLocalMsg').html('Are you sure you want to mark ' +
            '<em>' + name + '</em> instance as local ?');
        $('#markLocalDialog').modal("show");
    },

    markLocal: function () {
        var id = $('#instanceId').val();
        location.href='markLocal/' +parseInt(id);
        // var callback = function (response) {
        //     var result = $.parseJSON(response);
        //     $('#markLocalDialog').modal("hide");
        //     if (result.status) {
        //         showNotification(result.message, NotificationType.success);
        //     } else {
        //         showNotification(result.message, NotificationType.error);
        //     }
        // };
        //
        // var callObj = {
        //     url: 'markLocal/' + parseInt(id),
        //     method: HTTP_METHODS.GET,
        //     callback: callback
        // }
        // doAjax(callObj);
    },

};

$("#showHide").click(function() {
    if ($("#password").attr("type") == "password") {
        $("#password").attr("type", "text");
        $("#showHide").text("Hide");

    } else {
        $("#password").attr("type", "password");
        $("#showHide").text("Show");
    }
});

plmInstance.Form = {
    init: function () {

    }
}