package insight.npcil

import com.mongodb.MongoClient
import insight.npcil.datasync.model.PLMInstance
import insight.npcil.datasync.services.DBService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.context.annotation.Bean
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.data.mongodb.core.query.BasicQuery

@SpringBootApplication
class DataSyncApplication {
    @Autowired
    DBService dbService

    static void main(String[] args) {
        SpringApplication.run DataSyncApplication, args
    }

    @Bean
    PLMInstance getLocalInstance() {
        dbService.findOne(new BasicQuery('{type: \'local\'}'), PLMInstance.class)
    }
}
