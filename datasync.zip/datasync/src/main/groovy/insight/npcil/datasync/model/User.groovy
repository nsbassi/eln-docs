package insight.npcil.datasync.model

import insight.npcil.datasync.utils.Utils

/**
 * Created by nsb on 25/10/17.
 */
class User {
    String login, firstName, lastName, password

    String getPassword(){
        Utils.decrypt(password)
    }

    void setPassword(String password){
        this.password = Utils.encrypt(password)
    }

    @Override
    public String toString() {
        return "User{" +
                "login='" + login + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
