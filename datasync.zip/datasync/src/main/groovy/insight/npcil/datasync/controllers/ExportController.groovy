package insight.npcil.datasync.controllers

import insight.npcil.datasync.model.AgileTable
import insight.npcil.datasync.model.ExportConfig
import insight.npcil.datasync.services.AgileService
import insight.npcil.datasync.services.ConfigService
import insight.npcil.datasync.services.UserInfo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseBody

/**
 * Created by nsb on 24/10/17.
 */
@Controller
@RequestMapping('/export')
class ExportController {
    @Autowired
    UserInfo userInfo

    @Autowired
    ConfigService configService

    @RequestMapping('config/list')
    def list(Model model) {
        model.addAttribute('expList', configService.allExportConfigs)
        return 'config/list'
    }

    @RequestMapping('config/create/{id}')
    @ResponseBody
    def createExportConfig(@PathVariable int id) {
        if (configService.exportConfigExists(id))
            return [success: false, message: "Export config for this class already exists!"]
        else {
            ExportConfig config = configService.createExportConfig(id)
            return [success: true, message: "Export config created successfully for $config.agileClass class."]
        }
    }

    @RequestMapping(value = "config/delete/{id}")
    @ResponseBody
    def delete(@PathVariable int id) {
        try {
            configService.deleteExportConfig(id)
            return [success: true, message: "Export config deleted successfully."]
        } catch (Exception ex) {
            return [success: false, message: "Error while deleting the config."]
        }
    }

    @RequestMapping('config/{id}/tables')
    def expConfigTables(@PathVariable int id, Model model) {
        model << ['exp': configService.getExportConfig(id)]
        return 'config/tables'
    }

    @RequestMapping('config/{id}/{tblId}/attributes')
    def expConfig(@PathVariable int id, @PathVariable int tblId, Model model) {
        ExportConfig config = configService.getExportConfig(id)
        AgileTable tbl = config.tblList.find { it.id == tblId }
        model << [id: id, agileClass: config.agileClass, tbl: tbl]
        return 'config/attributes'
    }

    @RequestMapping('config/{id}/update')
    @ResponseBody
    def updateTables(@PathVariable int id, @RequestBody Map data) {
        boolean result = configService.updateExportTablesIncFlag(id, data)
        if (result)
            return [success: true, message: 'Records updated!!']
        else
            return [success: false, message: 'Unable to update records !']
    }

    @RequestMapping('config/{id}/{tblId}/update')
    @ResponseBody
    def updateAttributes(@PathVariable int id, @PathVariable int tblId, @RequestBody Map data) {
        boolean result = configService.updateExportAttributesIncFlag(id, tblId, data)
        if (result)
            return [success: true, message: 'Attributes updated!!']
        else
            return [success: false, message: 'Unable to update records !']
    }

}
