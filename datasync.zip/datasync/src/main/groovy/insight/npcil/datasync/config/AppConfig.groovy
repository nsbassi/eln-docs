package insight.npcil.datasync.config

import insight.npcil.datasync.interceptors.AuthCheckInterceptor
import insight.npcil.datasync.interceptors.LoginInterceptor
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Configuration
import org.springframework.web.servlet.config.annotation.InterceptorRegistry
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter

/**
 * Created by nsb on 18/05/16.
 */
@Configuration
class AppConfig extends WebMvcConfigurerAdapter {
    @Autowired
    LoginInterceptor loginInterceptor
    @Autowired
    AuthCheckInterceptor authCheckInterceptor

    Logger logger = LoggerFactory.getLogger(this.class)

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(loginInterceptor).addPathPatterns('/authenticate')
        registry.addInterceptor(authCheckInterceptor).excludePathPatterns('/login', '/notauthenticated', '/error', '/help')
    }
}