package insight.npcil.datasync.model

import com.agile.api.DataTypeConstants

/**
 * Created by nsb on 04/10/17.
 */
class AgileObject {
    String agileClass, number
    List<Table> tables
}

class Table {
    String name, id
    List<Map<String, Object>> rows
}