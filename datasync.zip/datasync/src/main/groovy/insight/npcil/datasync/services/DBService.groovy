package insight.npcil.datasync.services

import com.mongodb.CommandResult
import com.mongodb.DBObject
import com.mongodb.MongoClient
import insight.npcil.datasync.model.PLMInstance
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.mongodb.core.DbCallback
import org.springframework.data.mongodb.core.MongoOperations
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.data.mongodb.gridfs.GridFsOperations
import org.springframework.data.mongodb.gridfs.GridFsTemplate
import org.springframework.stereotype.Service

import javax.annotation.PostConstruct

/**
 * Created by nsb on 04/10/17.
 */
@Service
class DBService {

    @Delegate
    MongoOperations dbTemplate
    @Delegate
    GridFsOperations fsTemplate

    @Autowired
    MongoTemplate mongoTemplate

    @Autowired
    GridFsTemplate gridFsTemplate

    @Value('${spring.data.mongodb.database:npcildev}')
    String dbName

    @PostConstruct
    void init() {
        dbTemplate = mongoTemplate
        fsTemplate = gridFsTemplate
    }

    void saveInstance(PLMInstance instance) {
        save(instance)
    }

    @Override
    CommandResult executeCommand(DBObject command, int options) {
        return null
    }

    @Override
    def <T> T executeInSession(DbCallback<T> action) {
        return null
    }
}
