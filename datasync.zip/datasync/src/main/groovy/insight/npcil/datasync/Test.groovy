package insight.npcil.datasync

import com.agile.api.IAgileSession
import com.agile.api.IItem
import com.agile.api.ItemConstants
import insight.npcil.DataSyncApplication
import insight.npcil.datasync.model.ExportConfig
import insight.npcil.datasync.model.PLMInstance
import insight.npcil.datasync.model.User
import insight.npcil.datasync.services.AgileService
import insight.npcil.datasync.services.DBService
import org.springframework.context.ApplicationContext
import org.springframework.context.annotation.AnnotationConfigApplicationContext
import org.springframework.data.mongodb.core.query.BasicQuery

/**
 * Created by nsb on 04/10/17.
 */

ApplicationContext ctx = new AnnotationConfigApplicationContext(DataSyncApplication.class)
DBService service = ctx.getBean(DBService.class)

//service.insert(new PLMInstance(host: 'agile.ilsc.com',user:'admin',password: 'tartan', port: 7001, id:1, protocol: 'http', context: 'Agile'))
//AgileService agileService=ctx.getBean(AgileService.class)
//IAgileSession session = agileService.getSession()

//IItem doc = session.getObject(ItemConstants.CLASS_DOCUMENT, 'D02953')
//agileService.exportItem(doc)
//service.insert(  new ExportConfig(session.adminInstance.getAgileClass('Document'),"admin"))


service.save(new User(login:'admin', firstName: 'Navtej', lastName: 'Bassi', password: 'admin'))
println service.findOne(new BasicQuery("{login: 'admin'}"), User.class).password
//println new String(Base64.decoder.decode('[B@659a969b'.bytes))

