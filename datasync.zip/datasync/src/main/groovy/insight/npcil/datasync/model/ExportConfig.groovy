package insight.npcil.datasync.model

import com.agile.api.IAgileClass
import com.agile.api.IAttribute
import com.agile.api.ITableDesc
import org.springframework.data.annotation.Id

/**
 * Created by nsb on 04/10/17.
 */
class ExportConfig {
    int id
    String agileClass
    List<AgileTable> tblList
    Date createdOn, modifiedOn
    String createdBy, modifiedBy

    ExportConfig() {}

    ExportConfig(IAgileClass agileClass, String userName) {
        this.id = agileClass.id
        this.agileClass = agileClass.name
        this.tblList = agileClass.getTableDescriptors().collect {
            new AgileTable(it)
        }
        this.createdBy = userName
        this.modifiedBy = userName
        this.createdOn = new Date()
        this.modifiedOn = new Date()
    }
}

class AgileTable {
    String name
    int id
    List<Attribute> attrList
    boolean included

    AgileTable() {}

    AgileTable(ITableDesc desc) {
        name = desc.name
        id = desc.id
        included = true
        attrList = desc.attributes.findAll { it.visible }.collect {
            new Attribute(it)
        }
    }
}

class Attribute {
    String name, apiName
    int id
    boolean included

    Attribute() {}

    Attribute(IAttribute attr) {
        name = attr.name
        apiName = attr.APIName
        id = attr.id
        included = true
    }
}