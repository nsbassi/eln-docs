package insight.npcil.datasync.services

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

/**
 * Created by nsb on 24/10/17.
 */

@Component
//@Scope('session')
class UserInfo {
    String firstName, lastName
    boolean authenticated
}
