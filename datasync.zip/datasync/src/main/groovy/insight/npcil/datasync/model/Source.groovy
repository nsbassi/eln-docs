package insight.npcil.datasync.model

class PLMInstance {
    String host, context, user, password, type, protocol, mUrl, instanceName
    int id, port

    String getUrl() {
        "$protocol://$host:$port/$context"
    }
}

class TransferOrder {
    int sourceId
    List<Integer> destId
    Status expStatus
    List<Status> impStatus
    List objIdList
}

class StatusType {
    static final String PENDING = 'Pending'
    static final String EXP_CMP = 'Export Completed'
    static final String TR_CMP = 'Transfer Completed'
    static final String IMP_CMP = 'Import Completed'

    static final String EXP_CMP_WAR = 'Export Completed with Warnings'
    static final String TR_CMP_WAR = 'Export Completed with Warnings'
    static final String IMP_CMP_WAR = 'Export Completed with Warnings'

    static final String EXP_CMP_ERR = 'Export Completed with Warnings'
    static final String TR_CMP_ERR = 'Export Completed with Warnings'
    static final String IMP_CMP_ERR = 'Export Completed with Warnings'

    static final String EXP_FAILED = 'Export Failed'
    static final String TR_FAILED = 'Transfer Failed'
    static final String IMP_FAILED = 'Import Failed'

}

class Status {
    int envId
    StatusType status
}

class Counter {
    int counter
    String objectType
}