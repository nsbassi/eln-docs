package insight.npcil.datasync.model

/**
 * Created by nsb on 04/10/17.
 */
class ImportConfig {
}
