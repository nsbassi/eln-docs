package insight.npcil.datasync.utils

/**
 * Created by nsb on 26/10/17.
 */
class Utils {
    static String encrypt(String input) {
        new String(Base64.encoder.encode(input.bytes))
    }

    static String decrypt(String input) {
        new String(Base64.decoder.decode(input.bytes))
    }
}
