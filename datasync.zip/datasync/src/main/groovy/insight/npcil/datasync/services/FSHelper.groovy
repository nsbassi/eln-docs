package insight.npcil.datasync.services

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service

import javax.annotation.PostConstruct

/**
 * Created by nsb on 04/10/17.
 */
@Service
class FSHelper {
    @Value('${stagingDir:staging}')
    String stagingDirPath
    File stagingDir
    Logger logger = LoggerFactory.getLogger(FSHelper.class)

    @PostConstruct
    void init() {
        stagingDir = new File(stagingDirPath)
        if (!stagingDir.exists()) {
            try {
                stagingDir.mkdirs()
                logger.info("<$stagingDir.absolutePath> will be used as staging directory.")
            } catch (Exception ex) {
                logger.warn("Unable to access staging directory <$stagingDir.absolutePath>. This needs to be an existing directory with write permission for the export/import to work properly.")
            }
        }
    }
}
