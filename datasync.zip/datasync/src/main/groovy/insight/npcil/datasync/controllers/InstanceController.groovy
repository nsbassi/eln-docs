package insight.npcil.datasync.controllers

import insight.npcil.datasync.model.PLMInstance
import insight.npcil.datasync.model.Counter
import insight.npcil.datasync.services.DBService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.mongodb.core.query.BasicQuery
import org.springframework.data.mongodb.core.query.Update
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.servlet.mvc.support.RedirectAttributes

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import java.nio.file.Path

/**
 * Created by nsb on 26/10/17.
 */
@Controller
@RequestMapping('/instance')
class InstanceController {
    @Autowired
    DBService service

    /* @RequestMapping('create')
     @ResponseBody
     def create(@RequestBody PLMInstance instance) {
         def seq = service.findAndModify(new BasicQuery("{_id:'${PLMInstance.class.simpleName}'}"), new Update().inc('counter', 1 ), Counter.class)
         instance.id  = seq.counter
         service.save(instance)
         return [status: true, message: "New instance created !!"]
     }*/

    @RequestMapping('list')
    def list(Model model) {
        model << [instances: service.findAll(PLMInstance.class)]
        'instance/list'
    }

    @RequestMapping(value = ['edit/{id}', 'edit'])
    def edit(@PathVariable(required = false) String id, Model model) {
        model << [instance: id ? service.findById(Integer.parseInt(id), PLMInstance.class) : new PLMInstance()]
        'instance/edit'
    }

    @RequestMapping('update')
    def update(PLMInstance instance) {
        instance.type = 'remote'
        if (instance.id == 0) {
            def seq = service.findAndModify(new BasicQuery("{_id:'${PLMInstance.class.simpleName}'}"), new Update().inc('counter', 1), Counter.class)
            instance.id = seq.counter
            service.save(instance)
        } else {
            service.save(instance)
        }

        return 'redirect:/instance/list';
    }

    @RequestMapping('delete/{id}')
    @ResponseBody
    def delete(@PathVariable int id) {
        service.remove(new BasicQuery("{id:$id}"), PLMInstance.class)
        return [status: true, message: "Instance deleted successfully..!!"]
    }

    @RequestMapping('markLocal/{id}')
    def markLocal(@PathVariable int id, RedirectAttributes attr) {
        service.updateMulti(new BasicQuery("{}"), new Update().set('type', 'remote'), PLMInstance.class)
        PLMInstance instance = service.findById(id, PLMInstance.class)
        instance.type = 'local'
        service.save(instance)
        attr.addFlashAttribute("message", "Instance marked as local successfully..!!")
        return 'redirect:/instance/list'
    }

    def testConnection() {

    }
}
