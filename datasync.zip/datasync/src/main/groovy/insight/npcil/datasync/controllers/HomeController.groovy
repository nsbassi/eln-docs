package insight.npcil.datasync.controllers

import com.agile.api.ChangeConstants
import com.agile.api.IAgileClass
import com.agile.api.IAgileList
import com.agile.api.IAgileSession
import com.agile.api.ItemConstants
import insight.npcil.datasync.model.ExportConfig
import insight.npcil.datasync.services.AgileService
import insight.npcil.datasync.services.ConfigService
import insight.npcil.datasync.services.DBService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.mongodb.core.query.BasicQuery
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseBody

/**
 * Created by nsb on 05/10/17.
 */
@Controller
class HomeController {

    @Autowired
    ConfigService configService
    @Autowired
    AgileService agileService
    @Autowired
    DBService dbService


    @RequestMapping('/index')
    def index(Model model) {
        model << [data: dbService.findOne(new BasicQuery('{}'), Map.class, 'summary')]
        return 'index'
    }

    @RequestMapping('/login')
    def login(Model model) {
        return 'login'
    }

    @RequestMapping('/authenticate')
    def authenticate(@RequestParam String username, @RequestParam String password) {
        return 'index'
    }

    @RequestMapping('agile/classList')
    @ResponseBody
    def agileClasses() {
        return agileService.classes.collect { [id: it.id, text: it.name] }
    }

    @RequestMapping('/sch-jobs')
    def schJobs(Model model) {
        model.addAttribute('user', [firstName: 'Navtej', lastName: 'Bassi'])
        return 'sch-jobs'
    }

    @RequestMapping('/imp-config')
    def impConfig(Model model) {
        return 'imp-config'
    }

   @RequestMapping('/instances')
    def instances(Model model) {
        model.addAttribute('user', [firstName: 'Navtej', lastName: 'Bassi'])
        model.addAttribute('inst', configService.getPlmInstance())
        return 'instances'
    }


}
