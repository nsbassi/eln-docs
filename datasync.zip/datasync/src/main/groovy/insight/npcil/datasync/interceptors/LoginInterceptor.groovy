package insight.npcil.datasync.interceptors

import insight.npcil.datasync.model.User
import insight.npcil.datasync.services.DBService
import insight.npcil.datasync.services.UserInfo
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.mongodb.core.query.BasicQuery
import org.springframework.stereotype.Component
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

/**
 * Created by nsb on 25/10/17.
 */
@Component
class LoginInterceptor extends HandlerInterceptorAdapter {
    @Autowired
    UserInfo userInfo

    @Autowired
    DBService service

    Logger logger = LoggerFactory.getLogger(this.class)

    @Override
    boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        User user = service.findOne(new BasicQuery("{login: '${request.getParameter('username')}'}"), User.class)
        if (user?.password == request.getParameter('password')) {
            userInfo.firstName = user.firstName
            userInfo.lastName = user.lastName
            userInfo.authenticated = true
            response.sendRedirect('/index')
        } else {
            userInfo.authenticated = false
            response.sendRedirect('/login')
        }
    }
}
