package insight.npcil.datasync.interceptors

import com.agile.api.AgileSessionFactory
import com.agile.api.IAgileSession
import insight.npcil.datasync.services.UserInfo
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import org.springframework.web.servlet.ModelAndView
import org.springframework.web.servlet.SmartView
import org.springframework.web.servlet.View
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

/**
 * Created by nsb on 25/10/17.
 */
@Component
class AuthCheckInterceptor extends HandlerInterceptorAdapter {
    @Autowired
    UserInfo userInfo

    Logger logger = LoggerFactory.getLogger(this.class)

    @Override
    boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (userInfo?.authenticated) {
            true
        } else {
            response.sendRedirect('/login')
        }
    }

    @Override
    void postHandle(HttpServletRequest req, HttpServletResponse res, Object o, ModelAndView model) throws Exception {
        if (model != null && !isRedirectView(model))
            model.addObject('userInfo', userInfo)
    }

    static boolean isRedirectView(ModelAndView mv) {
        String viewName = mv.getViewName();
        if (viewName.startsWith("redirect:/")) {
            return true;
        }
        View view = mv.getView();
        return (view != null && view instanceof SmartView && view.isRedirectView());
    }
}
