package insight.npcil.datasync.services

import com.agile.api.IAgileSession
import insight.npcil.datasync.model.ExportConfig
import insight.npcil.datasync.model.PLMInstance
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.mongodb.core.query.BasicQuery
import org.springframework.data.mongodb.core.query.Query
import org.springframework.data.mongodb.core.query.Update
import org.springframework.stereotype.Service

import javax.xml.transform.Source

/**
 * Created by rajiv on 10/23/2017.
 */
@Service
class ConfigService {

    @Autowired
    DBService dbService
    @Autowired
    AgileService agileService
    @Autowired
    UserInfo userInfo

    List<ExportConfig> getAllExportConfigs() {
        dbService.findAll(ExportConfig.class)
    }

    ExportConfig getExportConfig(int id) {
        dbService.findById(id, ExportConfig.class)
    }

    boolean exportConfigExists(int id) {
        getExportConfig(id)
    }

    List<PLMInstance> getPlmInstance() {
        dbService.findAll(PLMInstance.class)
    }

    def createExportConfig(int id) {
        IAgileSession session = agileService.getSession()
        ExportConfig config = new ExportConfig(session.adminInstance.getAgileClass(id),
                "$userInfo.firstName $userInfo.lastName")
        dbService.insert(config)
        config
    }

    def deleteExportConfig(int id) {
        ExportConfig exportConfig = dbService.findById(id, ExportConfig.class)
        dbService.remove(exportConfig)
    }

    boolean updateExportTablesIncFlag(int id, Map data) {
        try {
            ExportConfig exportConfig = dbService.findById(id, ExportConfig.class)
            exportConfig.tblList.each {
                it.included = data["$it.id"]
            }
            dbService.save(exportConfig)
            return true
        } catch (Exception e) {
            e.printStackTrace()
            println('Exception occurred : ' + e.getMessage())
            return false
        }

    }

    boolean updateExportAttributesIncFlag(int clsId, int tblId, Map data) {
        try {
            ExportConfig exportConfig = dbService.findById(clsId, ExportConfig.class)
            exportConfig.tblList.find { it.id == tblId }.attrList.each {
                it.included = data["$it.id"]
            }
            dbService.save(exportConfig)
            return true
        } catch (Exception e) {
            e.printStackTrace()
            println('Exception occurred : ' + e.getMessage())
            return false
        }

    }

}
