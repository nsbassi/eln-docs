package insight.npcil.datasync.services

import com.agile.api.APIException
import com.agile.api.AgileSessionFactory
import com.agile.api.ChangeConstants
import com.agile.api.CommonConstants
import com.agile.api.DataTypeConstants
import com.agile.api.IAgileClass
import com.agile.api.IAgileSession
import com.agile.api.IAttachmentRow
import com.agile.api.IAttribute
import com.agile.api.ICell
import com.agile.api.IChange
import com.agile.api.IDataObject
import com.agile.api.INode
import com.agile.api.IQuery
import com.agile.api.IRow
import com.agile.api.ITable
import com.agile.api.ItemConstants
import com.agile.api.UserConstants
import insight.npcil.datasync.model.AgileObject
import insight.npcil.datasync.model.AgileTable
import insight.npcil.datasync.model.ExportConfig
import insight.npcil.datasync.model.PLMInstance
import insight.npcil.datasync.model.Table
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.mongodb.core.query.BasicQuery
import org.springframework.stereotype.Service

import javax.annotation.PostConstruct

/**
 * Created by nsb on 04/10/17.
 */
@Service
class AgileService {
    @Autowired
    PLMInstance instance

    @Autowired
    DBService dbService

    Logger logger = LoggerFactory.getLogger(AgileService.class)

    IAgileSession agileSession

    ITable getResults(IQuery query, List params) throws APIException {
        params ? query.execute(params as Object[]) : query.execute()
    }

    ITable getResults(IQuery query) throws APIException {
        getResults(query, null)
    }

    ITable getResults(String qry, String clsName, List params) {
        IQuery query
        if (clsName) {
            query = session.createObject(IQuery.OBJECT_TYPE, clsName)
            query.setCriteria(qry)
        } else {
            query = session.getObject(IQuery.OBJECT_TYPE, qry)
        }
        getResults(query, params)
    }

    ITable getResults(String qry, String clsName) {
        getResults(qry, clsName, null)
    }

    IAgileSession getSession() {
        agileSession?.isOpen() ? agileSession : connect(instance)
    }

    IAgileSession connect(PLMInstance instance) {
        AgileSessionFactory.getInstance(instance.url).createSession([(AgileSessionFactory.USERNAME): instance.user,
                                                                     (AgileSessionFactory.PASSWORD): instance.password])
    }

    List<IAgileClass> getClasses() {
        List out = []
        [ChangeConstants.CLASS_CHANGE_ORDERS_CLASS, ChangeConstants.CLASS_CHANGE_REQUESTS_CLASS,
         ItemConstants.CLASS_PARTS_CLASS, ItemConstants.CLASS_DOCUMENTS_CLASS].each {
            out.addAll(session.adminInstance.getAgileClass(it).subclasses)
        }
        out
    }

    void logout() {
        agileSession?.close()
    }

    void exportItem(IDataObject item) {
        String className = item.agileClass.name
        ExportConfig config = dbService.findOne(new BasicQuery("{agileClass: '$className'}"), ExportConfig.class)

        AgileObject aObj = new AgileObject(agileClass: className, number: item.name,
                tables: config?.tblList?.findAll {
                    it.included && it.id != CommonConstants.TABLE_ATTACHMENTS
                }?.collect {
                    logger.info("Processing table $it.name.")
                    new Table(id: it.id, name: it.name, rows: item.getTable(it.id).collect { IRow row ->
                        it.attrList.findAll { it.included }.collectEntries {
                            logger.info("Reading attribute $it.name.")
                            [(it.apiName): getValue(row.getCell(it.apiName))]
                        }
                    })
                })
        AgileTable attTable = config.tblList.find {
            it.included && it.id == CommonConstants.TABLE_ATTACHMENTS
        }

        if (attTable) {
            item.attachments?.each { IAttachmentRow row ->
                Map rowdata = attTable.attrList.findAll { it.included }.collectEntries {
                    logger.info("Reading attribute $it.name for attachment.")
                    [(it.apiName): getValue(row.getCell(it.apiName))]
                }
                rowdata << [number: item.name]
                dbService.store(row.file, rowdata)
            }
        }
        dbService.save(aObj)
    }

    private def getValue(ICell cell) {
        if (cell == null)
            return null
        IAttribute attr = cell.attribute
        try {
            def value = cell.value
            switch (attr.dataType) {
                case DataTypeConstants.TYPE_MULTILIST:
                    def selections = value.selection.collect {
                        it.value instanceof String ? it.value :
                                attr.listAgileClass?.isSubclassOf(UserConstants.CLASS_USER_BASE_CLASS) ?
                                        it.value.getValue(UserConstants.ATT_GENERAL_INFO_USER_ID) :
                                        it.value.name
                    }
                    value = selections.size() ? attr.listAgileClass ?
                            [type: 'multilist', value: selections, agileClass: attr.listAgileClass.name] :
                            [type: 'multilist', value: selections] : null
                    return value
                case DataTypeConstants.TYPE_SINGLELIST:
                    def selection = value.selection
                    if (selection.size()) {
                        if (attr.listAgileClass) {
                            if (attr.listAgileClass.isSubclassOf(UserConstants.CLASS_USER_BASE_CLASS)) {
                                value = [type : 'list', agileClass: attr.listAgileClass.name,
                                         value: selection[0].value.getValue(UserConstants.ATT_GENERAL_INFO_USER_ID)]
                            } else {
                                value = [type: 'list', value: selection[0].value.name, agileClass: attr.listAgileClass.name]
                            }
                        } else {
                            value = [type: 'list', value: selection[0].value instanceof String ?
                                    selection[0].value : selection[0].value.name]
                        }
                    } else {
                        value = null
                    }
                    return value
                case DataTypeConstants.TYPE_DATE:
                    return value ? [type: 'date', value: new Date(value.time)] : null
                case DataTypeConstants.TYPE_STRING:
                    return value ? [type: 'string', value: value] : null
                case DataTypeConstants.TYPE_INTEGER:
                    return value ? [type: 'integer', value: value] : null
                case DataTypeConstants.TYPE_DOUBLE:
                    return value ? [type: 'double', value: value] : null
                case DataTypeConstants.TYPE_MONEY:
                    return value ? [type: 'money', value: [amount: value.amount, currency: value.currency]] : null
                case DataTypeConstants.TYPE_OBJECT:
                    return value ? [type: 'object', value: value.name, agileClass: value.agileClass.name] : null
                case DataTypeConstants.TYPE_UNIT_OF_MEASURE:
                    return value ? [type: 'uom', value: value] : null
                case DataTypeConstants.TYPE_USER:
                    return value ? [type: 'user', value: value.value('userID'), agileClass: value.agileClass.name] :
                            null
                case DataTypeConstants.TYPE_TABLE:
                    return value ? [type: 'table', value: value] : null
                case DataTypeConstants.TYPE_WORKFLOW:
                    return value ? [type: 'workflow', value: value] : null
                case DataTypeConstants.TYPE_RULE:
                    return value ? [type: 'rule', value: value.collect { entry ->
                        entry.value instanceof INode ? entry.value.name :
                                [name: entry.value.name, agileClass: entry.value.agileClass.name]
                    }] : null;
                case DataTypeConstants.TYPE_FTS:
                    return value ? [type: 'fts', value: value] : null
                default:
                    return null;
            }
        } catch (Exception ex) {
            logger.error("Failed to read ${attr.fullName} on $aObj.agileClass.name $aObj.", ex)
        }
    }
}
