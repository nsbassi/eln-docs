/**
 * Created by rajiv on 10/23/2017.
 */

var exportConfig = {};
exportConfig.List = {
    init: function () {
        $('#btnAdd').click(function () {
            exportConfig.List.loadClasses();
            $('#newClassDialog').modal("show");
        });

        $('#lstClassType').change(function () {
            var selValue = $(this).val();
            if (selValue == '')
                return;
        });

        $('#btnCreate').click(function () {
            var selValue = $('#lstClassType').val();
            if (selValue == '') {
                showNotification("Please select a class Type!", NotificationType.error);
                return;
            }
            exportConfig.List.createClassConfig(selValue);
        });

        $('#btnDelete').click(function () {
            exportConfig.List.delete();
        });
    },

    confirmDelete: function (id, name) {
        $('#clsId').val(id);
        $('#deleteMsg').html('Are you sure you want to delete configuration for ' +
            '<em>' + name + '</em> class?');
        $('#deleteDialog').modal("show");
    },

    delete: function () {
        var id = $('#clsId').val();

        var callback = function (response) {
            var result = $.parseJSON(response);
            $('#deleteDialog').modal("hide");
            if (result.success) {
                showNotification(result.message, NotificationType.success);
                $('#__' + id).remove();
            } else {
                showNotification(result.message, NotificationType.error);
            }
        };
        var callObj = {
            url: 'delete/' + id,
            method: HTTP_METHODS.GET,
            callback: callback
        }
        doAjax(callObj);
    },

    loadClasses: function () {
        var callback = function (response) {
            var results = $.parseJSON(response);
            var html = '<option value="">Select...</option>';
            $.each(results, function (ind, obj) {
                html += '<option value="' + obj.id + '">' + obj.text + '</option>';
            });
            $('#lstClassType').html(html);
        };
        var callObj = {
            url: '/agile/classList',
            method: HTTP_METHODS.GET,
            callback: callback
        }
        doAjax(callObj);
    },

    createClassConfig: function (id) {
        var callback = function (response) {
            var result = $.parseJSON(response);
            if (result.success) {
                location.href = id + '/tables';
            } else {
                showNotification(result.message, NotificationType.error);
            }
        };
        var callObj = {
            url: 'create/' + id,
            method: HTTP_METHODS.GET,
            callback: callback
        }
        doAjax(callObj);
    }
}

exportConfig.Tables = {
    init: function () {
        $('#btnUpdateTbl').click(function () {
            exportConfig.Tables.saveData();
        });

        $('.chkDetails').change(function () {
            if ($(this)[0].checked)
                $($(this).parent().next()[0].lastChild).show()
            else
                $($(this).parent().next()[0].lastChild).hide()
        });

        $('.chkDetails').each(function () {
            if ($(this)[0].checked)
                $($(this).parent().next()[0].lastChild).show()
            else
                $($(this).parent().next()[0].lastChild).hide()
        });
    },

    saveData: function () {
        var data = {};
        $('.chkDetails').each(function (i, v) {
            data[v.id] = v.checked
        });

        var callback = function (response) {
            var result = $.parseJSON(response);
            if (result.success) {
                showNotification(result.message, NotificationType.success);
            } else {
                showNotification(result.message, NotificationType.error);
            }
        };

        var callObj = {
            url: 'update',
            data: JSON.stringify(data),
            method: HTTP_METHODS.POST,
            callback: callback
        }
        doAjax(callObj);
    }
}

exportConfig.Attributes = {
    init: function () {
        $('#btnUpdateAtr').click(function () {
            exportConfig.Attributes.saveData();
        });

        $('.chkDetails').change(function () {
            if ($(this)[0].checked)
                $($(this).parent().next()[0].lastChild).show()
            else
                $($(this).parent().next()[0].lastChild).hide()
        });

        $('.chkDetails').each(function () {
            if ($(this)[0].checked)
                $($(this).parent().next()[0].lastChild).show()
            else
                $($(this).parent().next()[0].lastChild).hide()
        });
    },

    saveData: function () {
        var data = {};
        $('.attrCheckBox').each(function (i, v) {
            data[v.id] = v.checked
        });

        var callback = function (response) {
            var result = $.parseJSON(response);
            if (result.success) {
                showNotification(result.message, NotificationType.success);
            } else {
                showNotification(result.message, NotificationType.error);
            }
        };

        var callObj = {
            url: 'update',
            data: JSON.stringify(data),
            method: HTTP_METHODS.POST,
            callback: callback
        }
        doAjax(callObj);
    }
}