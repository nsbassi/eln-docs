/**
 * Created by rajiv on 10/16/2017.
 */
HTTP_METHODS={
    GET : "GET",
    POST:"POST"
}
var NotificationType = {
    info : "info",
    success : "success",
    warn : "warn",
    error : "error"
}

function doAjax(transObj) {
    var vurl = transObj.url;
    var vmethod = transObj.method ? transObj.method : "GET";
    var vdata = transObj.data ? transObj.data : {};
    var vcontentType = "application/json;charset=utf-8";
    //var contentType="application/x-www-form-urlencoded; charset=UTF-8";
    if (transObj.hasOwnProperty('contentType'))
        vcontentType = transObj.contentType;
    var vprocessData = true;
    if (transObj.hasOwnProperty('contentType'))
        vprocessData = transObj.processData;
    var callback = transObj.callback ? transObj.callback : undefined;


    $.ajax({
        url: vurl,
        type: vmethod,
        data: vdata,
        contentType: vcontentType,
        processData: vprocessData,
        success: function (response) {

        },
        error: function (xhr, status, err) {
            $(".k-loading-mask").remove();
            alert(xhr.statusText);

        },
        complete: function (response) {

            if (callback && (typeof callback == "function")) {
                callback(response.responseText, arguments[1]);
            }
        }
    });
}

function showNotification(message, type, autoHide) {
    if (typeof data === 'undefined') {
        autoHide = true;
    }
    $.notify(message, {
        className : [ type, "test-position" ],
        globalPosition : 'top right',
        autoHide : autoHide,
        showAnimation : "fadeIn",
        hideAnimation : "fadeOut",
        hideDuration : 6000
    });
}
