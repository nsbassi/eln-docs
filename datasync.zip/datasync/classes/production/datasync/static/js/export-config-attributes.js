// /**
//  * Created by Akbar on 10/25/2017.
//  */
// $(document).ready(function() {
//     $("#btnUpdate").click(function(){
//         updateAttributeConfig();
//     });
//
// });
//
// function updateAttributeConfig() {
//
//     var selAttrList={};
//     $('.attrCheckBox').each(function (ind,obj) {
//         selAttrList[parseInt(obj.id)]=obj.checked;
//     });
//
//     var params={
//         className:$('#hidAgileClass').val(),
//         tableId:$('#hidTableID').val(),
//         attrList:selAttrList
//     };
//     $("#loader").show();
//     $.ajax({
//         dataType: "json",
//         url: '/updateattributes',
//         data : JSON.stringify(params),
//         type: "POST",
//         contentType : "application/json;charset=utf-8",
//         // contentType : "application/x-www-form-urlencoded; charset=UTF-8",
//         success: function (response) {
//             if(response.success) {
//                 showNotification(response.message, NotificationType.success);
//             }else{
//                 showNotification(response.message, NotificationType.error);
//             }
//             $("#loader").hide();
//         },
//         error: function (xhr, status, err) {
//             showNotification(err, NotificationType.error);
//             $("#loader").hide();
//         },
//         complete: function (response) {
//             $("#loader").hide();
//         }
//     });
// }