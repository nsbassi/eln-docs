import com.agile.api.*

IAgileSession session = AgileSessionFactory.getInstance('http://10.11.120.212:7001/Agile').
        createSession([(AgileSessionFactory.USERNAME): 'admin', (AgileSessionFactory.PASSWORD): 'agilenpcil'])