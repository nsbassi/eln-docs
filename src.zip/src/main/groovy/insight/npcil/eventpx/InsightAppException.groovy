package insight.npcil.eventpx

class InsightAppException extends Exception {
    private static final long serialVersionUID = 1L

    InsightAppException(String message) {
        super(message)
    }

    InsightAppException(String message, Throwable e) {
        super(message, e)
    }
}

