package insight.npcil.eventpx.techAuthorization

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class Application {
    static void main(String[] args) {
        SpringApplication app = new SpringApplication(Application.class)
        app.run(args)
    }
}