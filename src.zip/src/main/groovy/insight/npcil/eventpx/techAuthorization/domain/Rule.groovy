package insight.npcil.eventpx.techAuthorization.domain

class Rule {
    String operator, attr, taAttr, agileClass, type
    def value
    List<Rule> children

    static Rule buildRule(r) {
        Rule rule = new Rule(agileClass: r.@agileclass, taAttr: r.@taAttribute, type: r.@type, operator: r.@operator, attr: r.@attr)
        if (rule.type == 'complex') {
            rule.children = r.rule.collect {
                buildRule(it)
            }
        } else {
            def value = r.value.collect { it.text() }
            rule.value = value.size() == 1 ? value[0] : value
        }
        rule
    }

    boolean evaluate(Map params) {
        boolean res
        if (children) {
            if (operator == 'and') {
                res = true
                children.any { r ->
                    res = res && r.evaluate(params)
                    res == false
                }
                res
            } else if (operator == 'not') {
                res = !children[0].evaluate(params)
            } else if (operator == 'or') {
                res = false
                children.any { r ->
                    res = res || r.evaluate(params)
                    res == true
                }
                res
            } else {
                throw new Exception('Unsupported logical operator. Rule configuration needs to be corrected.')
            }
        } else {
            if (operator == 'equals') {
                params[attr] == value
            } else if (operator == 'in') {
                value.contains(params[attr])
            } else {
                throw new Exception('Unsupported operator. Rule configuration needs to be corrected.')
            }
        }
    }
}