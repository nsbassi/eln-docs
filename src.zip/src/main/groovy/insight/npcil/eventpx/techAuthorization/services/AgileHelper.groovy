package insight.npcil.eventpx.techAuthorization.services


import com.agile.api.*
import com.agile.px.ActionResult
import com.agile.px.EventActionResult
import insight.npcil.eventpx.InsightAppException
import insight.npcil.eventpx.techAuthorization.TACheckConfig
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

import javax.annotation.PostConstruct
import javax.annotation.PreDestroy
import java.text.DateFormat

import static com.agile.api.DataTypeConstants.*
import static com.agile.api.ItemConstants.*

@Component
class AgileHelper {
    @Value('${agile.url}')
    String agileUrl
    @Value('${agile.username}')
    String username
    @Value('${agile.password}')
    String password
    IAgileSession agileSession

    @Autowired
    TACheckConfig taConfig

    @PostConstruct
    void init() throws InsightAppException {
        this.@agileSession = session
    }

    IAgileSession getSession() throws InsightAppException {
        try {
            if (this.@agileSession?.isOpen()) {
                this.@agileSession
            } else {
                this.@agileSession = AgileSessionFactory.getInstance(this.agileUrl)
                        .createSession([(AgileSessionFactory.USERNAME): this.username,
                                        (AgileSessionFactory.PASSWORD): this.password])
                this.@agileSession
            }
        } catch (APIException ex) {
            throw new InsightAppException("Error while connecting with Agile.", ex)
        }
    }

    @PreDestroy
    void destroy() {
        this.@agileSession?.close()
    }

    IUser loadUser(String usrId) {
        session.getObject(IUser.OBJECT_TYPE, usrId)
    }

    IItem loadDocument(String docNum) {
        session.getObject(IItem.OBJECT_TYPE, docNum)
    }

    IChange loadChange(String changeNum) {
        session.getObject(IChange.OBJECT_TYPE, changeNum)
    }

    def isAuthorized(String number, String userId, String type) {
        isAuthorized(loadUser(userId), type == 'change' ? loadChange(number) : loadDocument(number))
    }

    def isAuthorized(IItem item, IUser user) {
        isAuthorized(item, user, ['Prepare'], 'Prepare')
    }

    String isAuthorized(IItem item, IUser user, List<String> actions, String status) {
        if (taCheckEnabled(item)) {
            IAttribute attrObj
            String attr = atrToCheck(item), usi = item.getValue('USI')
            attrObj = session.adminInstance.getAgileClass('Technical Authorization').getAttribute(attr)
            ITable taTable = loadTechAuthorizations(session, attrObj.objectId.toString(), actions, usi, user)
            if (taTable.iterator().hasNext()) {
                "$user authorized to signoff $attrObj.name for usi $usi at status $status."
            } else {
                "Valid Technical authorization to signoff $attrObj.name for usi $usi at status $status not found for $user."
            }
        }else{
            "Technical authorization check not enabled for $item.agileClass.name"
        }
    }

    String isAuthorized(IChange change, IUser user) {
        def actions = validAccessLevels(change.status)
        List<String> out = change.getTable(ChangeConstants.TABLE_AFFECTEDITEMS).collect { IItem item ->
            isAuthorized(item, user, actions, change.status.name)
        }.unique()
        List<String> errors = out.find { it.startsWith('Valid') }
        if (errors) {
            errors.join(' ')
        } else {
            "$user authorized to signoff all affected items for $change.agileClass.name $change.name at status $change.status.name."
        }
    }

    ITable loadTechAuthorizations(IAgileSession session, String atrToCheck, List validAccessLevels, String usi, IUser approver) {
        IQuery query = session.createObject(IQuery.OBJECT_TYPE, 'Technical Authorization')
        session.setDateFormats([taConfig.sdf] as DateFormat[])
        String criteria = new String(taConfig.taQueryTemplate)
        [atrToCheck: atrToCheck, validAccessLevels: validAccessLevels].each { k, v ->
            criteria.replaceAll("${k}", v)
        }
        query.setCriteria(criteria)
        query.setParams([approver, taConfig.sdf.format(new Date()), usi] as Object[])
        query.execute()
    }

    String atrToCheck(IItem itm) {
        String atrName
        Map map = toMap(itm)
        taConfig.rules[itm.agileClass.name].any { r ->
            if (r.evaluate(map)) {
                atrName = r.taAttr
                true
            } else {
                false
            }
        }
        atrName
    }

    List<String> validAccessLevels(IStatus status) {
        if (taConfig.prepareStatusList.contains(status.name)) {
            ['Prepare', 'Check', 'Review', 'Approve']
        } else if (taConfig.checkStatusList.contains(status.name)) {
            ['Check', 'Review', 'Approve']
        } else if (taConfig.reviewStatusList.contains(status.name)) {
            ['Check', 'Review']
        } else if (taConfig.approveStatusList.contains(status.name)) {
            ['Approve']
        } else {
            []
        }
    }

    Map toMap(IItem item) {
        Map out = [:]
        [TABLE_TITLEBLOCK, TABLE_PAGETWO, TABLE_PAGETHREE].each { tbl ->
            item.getTable(tbl).attributes.each { atr ->
                out << [(atr.APIName): getAttrValue(item, atr)]
            }
        }
        out
    }

    boolean taCheckEnabled(IDataObject dataObject) {
        taConfig.rules.keySet().contains(dataObject.agileClass.name)
    }

    private def getAttrValue(def item, IAttribute attr) {
        try {
            def value = item.getValue(attr)
            switch (attr.getDataType()) {
                case TYPE_MULTILIST:
                    def selections = value.selection.collect { it.value instanceof String ? it.value : it.value.name }
                    value = selections.size() ? attr.listAgileClass ?
                            selections : selections : null
                    return value
                case TYPE_SINGLELIST:
                    def selection = value.selection
                    value = selection.size() ? attr.listAgileClass ? selection[0].value.name :
                            selection[0].value instanceof String ? selection[0].value :
                                    selection[0].value instanceof IThumbnailID ? selection[0].value.caption :
                                            selection[0].value.name : null
                    return value
                case TYPE_DATE:
                    return value ? value : null
                case TYPE_STRING:
                    return value ? value : null
                case TYPE_INTEGER:
                    return value ? value : null
                case TYPE_DOUBLE:
                    return value ? value : null
                case TYPE_MONEY:
                    return value ? value.amount : null
                case TYPE_OBJECT:
                    return value ? value.name : null
                case TYPE_UNIT_OF_MEASURE:
                    return value ? value : null
                case TYPE_USER:
                    return value ? value.value('userID') : null
                case TYPE_TABLE:
                    return value ? value : null
                case TYPE_WORKFLOW:
                    return value ? value : null
                case TYPE_RULE:
                    return value ? value.collect { entry ->
                        entry.value instanceof INode ? entry.value.name :
                                entry.value.name
                    } : null
                case TYPE_FTS:
                    return value ? value : null
                default:
                    return null
            }
        } catch (Exception ex) {
            ex.printStackTrace()
        }
    }
}

