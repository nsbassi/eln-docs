package insight.npcil.eventpx.techAuthorization


import insight.npcil.eventpx.techAuthorization.domain.Rule
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.stereotype.Component

import javax.annotation.PostConstruct
import java.text.SimpleDateFormat

@Component
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "taConfig")
class TACheckConfig {
    List<String> prepareStatusList, reviewStatusList, checkStatusList, approveStatusList
    String ruleXMLFile, dateFormat, taQueryTemplate
    Map <String, List<Rule>> rules
    SimpleDateFormat sdf

    @PostConstruct
    void init() {
        rules = new XmlSlurper().parse(new File("$ruleXMLFile")).rule.collect { r ->
            Rule.buildRule(r)
        }.groupBy { it.agileClass }
        sdf = new SimpleDateFormat(dateFormat)
    }
}
