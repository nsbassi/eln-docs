package insight.npcil.eventpx.techAuthorization.controllers

import insight.npcil.eventpx.techAuthorization.services.AgileHelper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseBody

@Controller
class HomeController {
    @Autowired
    AgileHelper helper

    @RequestMapping('checkAuth')
    @ResponseBody
    String checkAuth(String number, String userId, String type){
        helper.isAuthorized(number, userId, type)
    }
}
